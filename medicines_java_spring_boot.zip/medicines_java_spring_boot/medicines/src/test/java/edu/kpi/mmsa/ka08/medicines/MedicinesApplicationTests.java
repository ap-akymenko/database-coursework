package edu.kpi.mmsa.ka08.medicines;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedicinesApplicationTests {

	@Test
	void contextLoads() {
	}

}
