package edu.kpi.mmsa.ka08.medicines.service;


import edu.kpi.mmsa.ka08.medicines.exception.ActionNotFoundException;
import edu.kpi.mmsa.ka08.medicines.model.Action;
import edu.kpi.mmsa.ka08.medicines.model.ActionId;
import edu.kpi.mmsa.ka08.medicines.repository.ActionRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Slf4j
@Service
public class ActionService {

    private final ActionRepository actionRepository;

    public ActionService(ActionRepository actionRepository) {
        this.actionRepository = actionRepository;
    }

    public List<Action> getActions() {
        return actionRepository.findAll();
    }

    public Action saveAction(Action newAction) {
        return actionRepository.save(newAction);
    }

    public Action getActionById(ActionId id) {
        Optional<Action> action = actionRepository.findById(id);
        if (action.isPresent()) {
            log.info("action: {}", action.get());
            return action.get();
        }
        throw new ActionNotFoundException();
    }

    public Action updateActionById(ActionId id, Action updatedAction) {
        Optional<Action> action = actionRepository.findById(id);
        if (action.isPresent()) {
            Action oldAction = action.get();
            log.info("action: {}", oldAction);
            updateAction(oldAction, updatedAction);
            return actionRepository.save(oldAction);
        }
        throw new ActionNotFoundException();
    }

    private void updateAction(Action oldAction, Action updatedAction) {
        oldAction.setIsForward(updatedAction.getIsForward());
    }

    public String deleteActionById(ActionId id) {
        actionRepository.deleteById(id);
        return "Action was successfully deleted!";
    }
}