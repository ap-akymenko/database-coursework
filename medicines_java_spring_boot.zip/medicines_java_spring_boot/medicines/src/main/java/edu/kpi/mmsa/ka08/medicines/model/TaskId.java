package edu.kpi.mmsa.ka08.medicines.model;

import java.io.Serializable;
import java.time.LocalDateTime;


public class TaskId implements Serializable {

    private String id;

    private LocalDateTime priceDate;

    public TaskId() {
    }

    public TaskId(String id, LocalDateTime priceDate) {
        this.id = id;
        this.priceDate = priceDate;
    }

}