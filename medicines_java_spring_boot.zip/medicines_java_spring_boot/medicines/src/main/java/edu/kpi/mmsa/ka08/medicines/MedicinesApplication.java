package edu.kpi.mmsa.ka08.medicines;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedicinesApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedicinesApplication.class, args);
	}

}
