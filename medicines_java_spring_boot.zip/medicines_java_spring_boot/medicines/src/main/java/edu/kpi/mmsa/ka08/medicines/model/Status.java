package edu.kpi.mmsa.ka08.medicines.model;

import com.sun.istack.NotNull;

import javax.persistence.*;

@Entity
@Table(name = "statuses")
public class Status {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    private String  description;

    @NotNull
    private Boolean processing;

    public Status() {
    }

    public Status(Long id, String description, Boolean processing) {
        this.id = id;
        this.description = description;
        this.processing = processing;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Boolean getProcessing() {
        return processing;
    }

    public void setProcessing(Boolean processing) {
        this.processing = processing;
    }
}