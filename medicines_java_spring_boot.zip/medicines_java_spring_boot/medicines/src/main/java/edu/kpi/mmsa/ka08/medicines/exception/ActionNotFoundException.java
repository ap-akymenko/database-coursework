package edu.kpi.mmsa.ka08.medicines.exception;

public class ActionNotFoundException extends RuntimeException{
}
