package edu.kpi.mmsa.ka08.medicines.service;

import edu.kpi.mmsa.ka08.medicines.exception.StatusNotFoundException;
import edu.kpi.mmsa.ka08.medicines.model.Status;
import edu.kpi.mmsa.ka08.medicines.repository.StatusRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Slf4j
@Service
public class StatusService {

    private final StatusRepository statusRepository;

    @Autowired
    public StatusService(StatusRepository statusRepository) {
        this.statusRepository = statusRepository;
    }

    public List<Status> getStatuses() {
        return statusRepository.findAll();
    }

    public Status saveStatus(Status newStatus) {
        return statusRepository.save(newStatus);
    }

    public Status getStatusById(Long id) {
        Optional<Status> status = statusRepository.findById(id);
        if (status.isPresent()) {
            log.info("status: {}", status.get());
            return status.get();
        }
        throw new StatusNotFoundException();
    }

    public Status updateStatusById(Long id, Status updatedStatus) {
        Optional<Status> status = statusRepository.findById(id);
        if (status.isPresent()) {
            Status oldStatus = status.get();
            log.info("status: {}", oldStatus);
            updateStatus(oldStatus, updatedStatus);
            return statusRepository.save(oldStatus);
        }
        throw new StatusNotFoundException();
    }

    private void updateStatus(Status oldStatus, Status updatedStatus) {
        oldStatus.setDescription(updatedStatus.getDescription());
        oldStatus.setProcessing(updatedStatus.getProcessing());
    }

    public String deleteStatusById(Long id) {
        statusRepository.deleteById(id);
        return "Status was successfully deleted!";
    }
}