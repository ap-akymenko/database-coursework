package edu.kpi.mmsa.ka08.medicines.service;

import edu.kpi.mmsa.ka08.medicines.exception.RequestNotFoundException;
import edu.kpi.mmsa.ka08.medicines.model.Request;
import edu.kpi.mmsa.ka08.medicines.repository.RequestRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Slf4j
@Service
public class RequestService {

    private final RequestRepository requestRepository;

    public RequestService(RequestRepository requestRepository) {
        this.requestRepository = requestRepository;
    }

    public List<Request> getRequests() {
        return requestRepository.findAll();
    }

    public Request saveRequest(Request newRequest) {
        return requestRepository.save(newRequest);
    }

    public Request getRequestById(Long id) {
        Optional<Request> request = requestRepository.findById(id);
        if (request.isPresent()) {
            log.info("request: {}", request.get());
            return request.get();
        }
        throw new RequestNotFoundException();
    }

    public Request updateRequestById(Long id, Request updatedRequest) {
        Optional<Request> request = requestRepository.findById(id);
        if (request.isPresent()) {
            Request oldRequest = request.get();
            log.info("request: {}", oldRequest);
            updateRequest(oldRequest, updatedRequest);
            return requestRepository.save(oldRequest);
        }
        throw new RequestNotFoundException();
    }

    private void updateRequest(Request oldRequest, Request updatedRequest) {
        oldRequest.setTaskId(updatedRequest.getTaskId());
        oldRequest.setWorkerId(updatedRequest.getWorkerId());
        oldRequest.setStatusId(updatedRequest.getStatusId());
    }

    public String deleteRequestById(Long id) {
        requestRepository.deleteById(id);
        return "Request was successfully deleted!";
    }

}
