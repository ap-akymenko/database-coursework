package edu.kpi.mmsa.ka08.medicines.controller;

import edu.kpi.mmsa.ka08.medicines.model.Action;
import edu.kpi.mmsa.ka08.medicines.model.ActionId;
import edu.kpi.mmsa.ka08.medicines.service.ActionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

@Controller
public class ActionController {

    private final ActionService actionService;

    @Autowired
    public ActionController(ActionService actionService) {
        this.actionService = actionService;
    }

    @GetMapping(value = "/action")
    public ResponseEntity<List<Action>> getActions() {
        return ResponseEntity.ok(actionService.getActions());
    }

    @PostMapping(value = "/action")
    public ResponseEntity<Action> postActions(@RequestBody Action newAction) {
        return ResponseEntity.ok(actionService.saveAction(newAction));
    }

    @GetMapping(value = "/action/{request_id}/{user_id}")
    public ResponseEntity<Action> getAction(@PathVariable Long request_id, @PathVariable Long user_id) {
        ActionId actionId = new ActionId(request_id, user_id);
        return ResponseEntity.ok(actionService.getActionById(actionId));
    }

    @PutMapping(value = "/action/{request_id}/{user_id}")
    public ResponseEntity<Action> updateAction(@PathVariable Long request_id, @PathVariable Long user_id, @RequestBody Action updatedAction) {
        ActionId actionId = new ActionId(request_id, user_id);
        return ResponseEntity.ok(actionService.updateActionById(actionId, updatedAction));
    }

    @DeleteMapping(value = "/action/{request_id}/{user_id}")
    public ResponseEntity<String> deleteAction(@PathVariable Long request_id, @PathVariable Long user_id) {
        ActionId actionId = new ActionId(request_id, user_id);
        return ResponseEntity.ok(actionService.deleteActionById(actionId));
    }

}
