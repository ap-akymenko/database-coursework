package edu.kpi.mmsa.ka08.medicines.model;

import java.io.Serializable;


public class ActionId implements Serializable {

    private Long requestId;

    private Long userId;

    public ActionId() {}

    public ActionId(Long requestId, Long userId) {
        this.requestId = requestId;
        this.userId = userId;
    }

}