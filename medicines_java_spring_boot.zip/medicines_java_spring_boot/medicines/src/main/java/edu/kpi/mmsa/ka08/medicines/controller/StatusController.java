package edu.kpi.mmsa.ka08.medicines.controller;

import edu.kpi.mmsa.ka08.medicines.model.Status;
import edu.kpi.mmsa.ka08.medicines.service.StatusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class StatusController {

    private final StatusService statusService;

    @Autowired
    public StatusController(StatusService statusService) {
        this.statusService = statusService;
    }

    @GetMapping(value = "/status")
    public ResponseEntity<List<Status>> getStatuses() {
        return ResponseEntity.ok(statusService.getStatuses());
    }

    @PostMapping("/status")
    public ResponseEntity<Status> postStatus(@RequestBody Status newStatus) {
        return ResponseEntity.ok(statusService.saveStatus(newStatus));
    }

    @GetMapping(value = "/status/{id}")
    public ResponseEntity<Status> getStatus(@PathVariable Long id) {
        return ResponseEntity.ok(statusService.getStatusById(id));
    }

    @PutMapping(value = "/status/{id}")
    public ResponseEntity<Status> updateStatus(@PathVariable Long id, @RequestBody Status updatedStatus) {
        return ResponseEntity.ok(statusService.updateStatusById(id, updatedStatus));
    }

    @DeleteMapping(value = "/status/{id}")
    public ResponseEntity<String> deleteStatus(@PathVariable Long id) {
        return ResponseEntity.ok(statusService.deleteStatusById(id));
    }

}