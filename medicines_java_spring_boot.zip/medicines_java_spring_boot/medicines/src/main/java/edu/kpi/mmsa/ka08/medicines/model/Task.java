package edu.kpi.mmsa.ka08.medicines.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.ToString;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@IdClass(TaskId.class)
@Table(name = "tasks")
@ToString
public class Task {

    @Id
    @NotNull
    private String id;

    @NotNull
    private BigDecimal price;

    @Id
    @NotNull
    @Column(name = "price_date")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private LocalDateTime priceDate;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public LocalDateTime getPriceDate() {
        return priceDate;
    }

    public void setPriceDate(LocalDateTime priceDate) {
        this.priceDate = priceDate;
    }
}
