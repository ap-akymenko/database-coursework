package edu.kpi.mmsa.ka08.medicines.controller;

import edu.kpi.mmsa.ka08.medicines.model.Request;
import edu.kpi.mmsa.ka08.medicines.service.RequestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class RequestController {

    private final RequestService requestService;

    @Autowired
    public RequestController(RequestService requestService) {
        this.requestService = requestService;
    }

    @GetMapping(value = "/request")
    public ResponseEntity<List<Request>> getRequests() {
        return ResponseEntity.ok(requestService.getRequests());
    }

    @PostMapping(value = "/request")
    public ResponseEntity<Request> postRequests(@RequestBody Request newRequest) {
        return ResponseEntity.ok(requestService.saveRequest(newRequest));
    }

    @GetMapping(value = "/request/{id}")
    public ResponseEntity<Request> getRequest(@PathVariable Long id) {
        return ResponseEntity.ok(requestService.getRequestById(id));
    }

    @PutMapping(value = "/request/{id}")
    public ResponseEntity<Request> updateRequest(@PathVariable Long id, @RequestBody Request updatedRequest) {
        return ResponseEntity.ok(requestService.updateRequestById(id, updatedRequest));
    }

    @DeleteMapping(value = "/request/{id}")
    public ResponseEntity<String> deleteRequest(@PathVariable Long id) {
        return ResponseEntity.ok(requestService.deleteRequestById(id));
    }

}
