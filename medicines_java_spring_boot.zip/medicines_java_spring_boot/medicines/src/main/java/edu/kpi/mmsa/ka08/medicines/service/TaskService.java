package edu.kpi.mmsa.ka08.medicines.service;

import edu.kpi.mmsa.ka08.medicines.exception.TaskNotFoundException;
import edu.kpi.mmsa.ka08.medicines.model.Task;
import edu.kpi.mmsa.ka08.medicines.model.TaskId;
import edu.kpi.mmsa.ka08.medicines.repository.TaskRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Slf4j
@Service
public class TaskService {

    private final TaskRepository taskRepository;

    public TaskService(TaskRepository taskRepository) {
        this.taskRepository = taskRepository;
    }

    public List<Task> getTasks() {
        return taskRepository.findAll();
    }

    public Task saveTask(Task newTask) {
        return taskRepository.save(newTask);
    }

    public Task getTaskById(TaskId id) {
        Optional<Task> task = taskRepository.findById(id);
        if (task.isPresent()) {
            log.info("task: {}", task.get());
            return task.get();
        }
        throw new TaskNotFoundException();
    }

    public Task updateTaskById(TaskId id, Task updatedTask) {
        Optional<Task> task = taskRepository.findById(id);
        if (task.isPresent()) {
            Task oldTask = task.get();
            log.info("task: {}", oldTask);
            updateTask(oldTask, updatedTask);
            return taskRepository.save(oldTask);
        }
        throw new TaskNotFoundException();
    }

    private void updateTask(Task oldTask, Task updatedTask) {
        oldTask.setPrice(updatedTask.getPrice());
    }

    public String deleteTaskById(TaskId id) {
        taskRepository.deleteById(id);
        return "Task was successfully deleted!";
    }
}
