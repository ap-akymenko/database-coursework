package edu.kpi.mmsa.ka08.medicines.service;


import edu.kpi.mmsa.ka08.medicines.exception.UserNotFoundException;
import edu.kpi.mmsa.ka08.medicines.model.User;
import edu.kpi.mmsa.ka08.medicines.repository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Slf4j
@Service
public class UserService {

    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public List<User> getUsers() {
        return userRepository.findAll();
    }

    public User saveUser(User newUser) {
        return userRepository.save(newUser);
    }

    public User getUserById(Long id) {
        Optional<User> user = userRepository.findById(id);
        if (user.isPresent()) {
            log.info("user: {}", user.get());
            return user.get();
        }
        throw new UserNotFoundException();
    }

    public User updateUserById(Long id, User updatedUser) {
        Optional<User> user = userRepository.findById(id);
        if (user.isPresent()) {
            User oldUser = user.get();
            log.info("user: {}", oldUser);
            updateUser(oldUser, updatedUser);
            return userRepository.save(oldUser);
        }
        throw new UserNotFoundException();
    }

    private void updateUser(User oldUser, User updatedUser) {
        oldUser.setName(updatedUser.getName());
        oldUser.setSurname(updatedUser.getSurname());
        oldUser.setPassword(updatedUser.getPassword());
        oldUser.setRoleId(updatedUser.getRoleId());
    } //TODO user update doesn't update his date_registration

    public String deleteUserById(Long id) {
        userRepository.deleteById(id);
        return "User was successfully deleted!";
    }

    //TODO user can't be deleted (And all other things in database too as well)
}