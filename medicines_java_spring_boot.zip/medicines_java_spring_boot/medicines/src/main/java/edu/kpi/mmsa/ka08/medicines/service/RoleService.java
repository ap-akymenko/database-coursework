package edu.kpi.mmsa.ka08.medicines.service;

import edu.kpi.mmsa.ka08.medicines.exception.RoleNotFoundException;
import edu.kpi.mmsa.ka08.medicines.model.Role;
import edu.kpi.mmsa.ka08.medicines.repository.RoleRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Slf4j
@Service
public class RoleService {

    private final RoleRepository roleRepository;

    public RoleService(RoleRepository roleRepository) {
        this.roleRepository = roleRepository;
    }

    public List<Role> getRoles() {
        return roleRepository.findAll();
    }

    public Role saveRole(Role newRole) {
        return roleRepository.save(newRole);
    }

    public Role getRoleById(Long id) {
        Optional<Role> role = roleRepository.findById(id);
        if (role.isPresent()) {
            log.info("role: {}", role.get());
            return role.get();
        }
        throw new RoleNotFoundException();
    }

    public Role updateRoleById(Long id, Role updatedRole) {
        Optional<Role> role = roleRepository.findById(id);
        if (role.isPresent()) {
            Role oldRole = role.get();
            log.info("role: {}", oldRole);
            updateRole(oldRole, updatedRole);
            return roleRepository.save(oldRole);
        }
        throw new RoleNotFoundException();
    }

    private void updateRole(Role oldRole, Role updatedRole) {
        oldRole.setDescription(updatedRole.getDescription());
    }

    public String deleteRoleById(Long id) {
        roleRepository.deleteById(id);
        return "Role was successfully deleted!";
    }
}
