package edu.kpi.mmsa.ka08.medicines.controller;

import edu.kpi.mmsa.ka08.medicines.model.Task;
import edu.kpi.mmsa.ka08.medicines.model.TaskId;
import edu.kpi.mmsa.ka08.medicines.service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.time.LocalDateTime;
import java.util.List;

@Controller
public class TaskController {

    private final TaskService taskService;

    @Autowired
    public TaskController(TaskService taskService) {
        this.taskService = taskService;
    }

    @GetMapping(value = "/task")
    public ResponseEntity<List<Task>> getTasks() {
        return ResponseEntity.ok(taskService.getTasks());
    }

    @PostMapping(value = "/task")
    public ResponseEntity<Task> postTasks(@RequestBody Task newTask) {
        return ResponseEntity.ok(taskService.saveTask(newTask));
    }

    @GetMapping(value = "/task/{id}/{price_date}")
    public ResponseEntity<Task> getTask(@PathVariable String id, @PathVariable LocalDateTime price_date) {
        TaskId taskId = new TaskId(id, price_date);
        return ResponseEntity.ok(taskService.getTaskById(taskId));
    }

    @PutMapping(value = "/task/{id}/{price_date}")
    public ResponseEntity<Task> updateTask(@PathVariable String id, @PathVariable LocalDateTime price_date, @RequestBody Task updatedTask) {
        TaskId taskId = new TaskId(id, price_date);
        return ResponseEntity.ok(taskService.updateTaskById(taskId, updatedTask));
    }

    @DeleteMapping(value = "/task/{id}/{price_date}")
    public ResponseEntity<String> deleteTask(@PathVariable String id, @PathVariable LocalDateTime price_date) {
        TaskId taskId = new TaskId(id, price_date);
        return ResponseEntity.ok(taskService.deleteTaskById(taskId));
    }
}
