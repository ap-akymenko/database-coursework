package edu.kpi.mmsa.ka08.medicines.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.ToString;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;


@Entity
@IdClass(ActionId.class)
@Table(name = "actions")
@ToString
public class Action {

    @UpdateTimestamp
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private LocalDateTime time;

    @Id
    @NotNull
    @Column(name = "request_id")
    private Long requestId;

    @Id
    @NotNull
    @Column(name = "user_id")
    private Long userId;

    @Column(name = "answer")
    @NotNull
    private Boolean isForward;

    public LocalDateTime getTime() {return time;}

    public void setTime(LocalDateTime time) {this.time = time;}

    public Long getRequestId() {return requestId;}

    public void setRequestId(Long requestId) {this.requestId = requestId;}

    public Long getUserId() {return userId;}

    public void setUserId(Long userId) {this.userId = userId;}

    public Boolean getIsForward() {return isForward;}

    public void setIsForward(Boolean forward) {isForward = forward;}

}