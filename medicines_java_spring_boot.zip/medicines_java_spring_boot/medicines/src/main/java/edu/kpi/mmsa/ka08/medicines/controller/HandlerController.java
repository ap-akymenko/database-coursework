package edu.kpi.mmsa.ka08.medicines.controller;

import edu.kpi.mmsa.ka08.medicines.exception.*;
import edu.kpi.mmsa.ka08.medicines.model.Error;
import edu.kpi.mmsa.ka08.medicines.model.Role;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import java.util.Optional;

@ControllerAdvice
public class HandlerController {
    
    @ExceptionHandler(value = {StatusNotFoundException.class})
    protected ResponseEntity<Error> statusHandleConflict(StatusNotFoundException ex, WebRequest request) {
        Error error = Error.builder().code("BAD_REQUEST").description("Status Not Found").build();
        return ResponseEntity.of(Optional.of(error)).notFound().build();
    }

    @ExceptionHandler(value = {ActionNotFoundException.class})
    protected ResponseEntity<Error> actionHandleConflict(ActionNotFoundException ex, WebRequest request) {
        Error error = Error.builder().code("BAD_REQUEST").description("Action Not Found").build();
        return ResponseEntity.of(Optional.of(error)).notFound().build();
    }

    @ExceptionHandler(value = {RequestNotFoundException.class})
    protected ResponseEntity<Error> requestHandleConflict(RequestNotFoundException ex, WebRequest request) {
        Error error = Error.builder().code("BAD_REQUEST").description("Request Not Found").build();
        return ResponseEntity.of(Optional.of(error)).notFound().build();
    }

    @ExceptionHandler(value = {RoleNotFoundException.class})
    protected ResponseEntity<Error> roleHandleConflict(RoleNotFoundException ex, WebRequest request) {
        Error error = Error.builder().code("BAD_REQUEST").description("Role Not Found").build();
        return ResponseEntity.of(Optional.of(error)).notFound().build();
    }

//    @ExceptionHandler(value = {TaskNotFoundException.class})
//    protected ResponseEntity<Error> taskHandleConflict(TaskNotFoundException ex, WebRequest request) {
//        Error error = Error.builder().code("BAD_REQUEST").description("Task Not Found").build();
//        return ResponseEntity.of(Optional.of(error)).notFound().build();
//    }

    @ExceptionHandler(value = {UserNotFoundException.class})
    protected ResponseEntity<Error> userHandleConflict(UserNotFoundException ex, WebRequest request) {
        Error error = Error.builder().code("BAD_REQUEST").description("User Not Found").build();
        return ResponseEntity.of(Optional.of(error)).notFound().build();
    }
}
